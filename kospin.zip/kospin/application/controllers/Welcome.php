<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Welcome extends CI_Controller {

	/**
	 * Index Page for this controller.
	 *
	 * Maps to the following URL
	 * 		http://example.com/index.php/welcome
	 *	- or -
	 * 		http://example.com/index.php/welcome/index
	 *	- or -
	 * Since this controller is set as the default controller in
	 * config/routes.php, it's displayed at http://example.com/
	 *
	 * So any other public methods not prefixed with an underscore will
	 * map to /index.php/welcome/<method_name>
	 * @see https://codeigniter.com/user_guide/general/urls.html
	 */

	function __construct(){
		parent::__construct();		
		$this->load->model('input_m');
		$this->load->helper('form','url');
	}
	
	public function index()
	{
		redirect('Welcome/beranda');
	}
	public function beranda()
	{
		$data['page'] = $this->load->view('beranda', '', TRUE);
		$this->load->view('index',$data);
	}
	public function tentang()
	{
		$data['page'] = $this->load->view('tentang', '', TRUE);
		$this->load->view('index',$data);
	}
	public function koperasi()
	{
		$data['page'] = $this->load->view('koperasi', '', TRUE);
		$this->load->view('index',$data);
	}
	public function galeri()
	{
		$data['page'] = $this->load->view('galeri', '', TRUE);
		$this->load->view('index',$data);
	}
	public function kontak()
	{
		$data['page'] = $this->load->view('kontak', '', TRUE);
		$this->load->view('index',$data);
	}
	public function input_data(){
		$fname	=	$this->input->post('fname');
		$lname	=	$this->input->post('lname');
		$mail	=	$this->input->post('mail');
		$msg	=	$this->input->post('msg');

		$data = array(
			'first_name'	=>	$fname,
			'last_name'		=>	$lname,
			'email'			=>	$mail,
			'msg'			=>	$msg
		);

		$this->input_m->add_data($data,'datadb');
		redirect('Welcome/kontak');
	}
}
