<body data-spy="scroll" data-target=".site-navbar-target" data-offset="300">

    
    <div class="site-wrap" id="home-section">

      <div class="site-mobile-menu site-navbar-target">
        <div class="site-mobile-menu-header">
          <div class="site-mobile-menu-close mt-3">
            <span class="icon-close2 js-menu-toggle"></span>
          </div>
        </div>
        <div class="site-mobile-menu-body"></div>
      </div>

 
    <div class="ftco-blocks-cover-1">
       <!-- data-stellar-background-ratio="0.5" style="background-image: url('images/hero_1.jpg')" -->
      <div class="site-section-cover overlay" data-stellar-background-ratio="0.5" style="background-image: url('../assets/images/hero_1.jpg')">
        <div class="container">
          <div class="row align-items-center ">

            <div class="col-md-5 mt-5 pt-5">
              <span class="text-cursive h5 text-red">Galeri</span>
              <h1 class="mb-3 font-weight-bold text-teal">Galeri Koperasi</h1>
              <p><a href="index.html" class="text-white">Menu</a> <span class="mx-3">/</span> <strong>Galeri</strong></p>
            </div>
            
          </div>
        </div>
      </div>
    </div>


    <div class="site-section">
      <div class="container">
        <div class="row mb-5">
          <div class="col-12 text-center">
            <span class="text-cursive h5 text-red d-block">e-Kospin</span>
            <h2 class="text-black">Galeri</h2>
          </div>
        </div>
        <div class="row">
          <div class="col-md-3 mb-4">
            <a href="images/img_1.jpg" data-fancybox="gal"><img src="../assets/images/img_1.jpg" alt="Image" class="img-fluid"></a>
          </div>
          <div class="col-md-3 mb-4">
            <a href="images/img_2.jpg" data-fancybox="gal"><img src="../assets/images/img_2.jpg" alt="Image" class="img-fluid"></a>
          </div>
          <div class="col-md-3 mb-4">
            <a href="images/img_3.jpg" data-fancybox="gal"><img src="../assets/images/img_3.jpg" alt="Image" class="img-fluid"></a>
          </div>
          <div class="col-md-3 mb-4">
            <a href="images/img_4.jpg" data-fancybox="gal"><img src="../assets/images/img_4.jpg" alt="Image" class="img-fluid"></a>
          </div>

          <div class="col-md-3 mb-4">
            <a href="images/img_5.jpg" data-fancybox="gal"><img src="../assets/images/img_5.jpg" alt="Image" class="img-fluid"></a>
          </div>
          <div class="col-md-3 mb-4">
            <a href="images/img_2.jpg" data-fancybox="gal"><img src="../assets/images/img_3.jpg" alt="Image" class="img-fluid"></a>
          </div>
          <div class="col-md-3 mb-4">
            <a href="images/img_2.jpg" data-fancybox="gal"><img src="../assets/images/img_2.jpg" alt="Image" class="img-fluid"></a>
          </div>
          <div class="col-md-3 mb-4">
            <img src="../assets/images/img_1.jpg" alt="Image" class="img-fluid">
          </div>
        </div>
      </div>
    </div>